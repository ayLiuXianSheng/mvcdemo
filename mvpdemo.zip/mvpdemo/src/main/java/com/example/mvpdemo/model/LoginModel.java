package com.example.mvpdemo.model;

/**
 * Created by mamiaomiao on 2018/1/30.
 * model层处理数据
 */

public class LoginModel {

    public boolean isLogin(String name, String pwd) {

        if(name.equals("xiaohong")&&pwd.equals("123123")){
            return  true;
        }
        return false;
    }
}
