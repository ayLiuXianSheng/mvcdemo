package com.example.mvpnetworkdemo.contract;

/**
 * Created by mamiaomiao on 2018/1/31.
 */

public interface ISearchView {
    //输入框获取内容
    String getText();
    //显示搜索结果
    void setShow(String data);
}
