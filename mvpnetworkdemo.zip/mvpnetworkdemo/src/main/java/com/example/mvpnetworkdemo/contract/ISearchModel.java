package com.example.mvpnetworkdemo.contract;

/**
 * Created by mamiaomiao on 2018/1/31.
 */

public interface ISearchModel {
    void search(final String key, DataCallBack callBack);
}
