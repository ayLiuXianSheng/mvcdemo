package com.example.qqlogin.wxapi;

import com.umeng.weixin.callback.WXCallbackActivity;


/**
 * Created by mamiaomiao on 2018/2/2.
 */

public class WXEntryActivity extends WXCallbackActivity {
}
